# Raja Suit

Raja Suit is a game that grow with player. With the help of Core ML, everytime player plays, the Genie is getting stronger and stronger.

# Rules

There are three available animals, each has one weakness and one strength.

1. Ant, can beat Elephant.
2. Elephant, can beat Giraffe.
3. Giraffe, can beat Ant.

# How to Play

Pick one from three available animal to fight your opponent.

# License

Icon made by [Freepik](https://www.flaticon.com/authors/freepik) from [www.flaticon.com](http://www.flaticon.com/).

# Reference

[How to run Core ML in playground](https://heartbeat.fritz.ai/how-to-run-and-test-core-ml-models-in-swift-playgrounds-8e4b4f9cf676)

[Permutation and Combination in Python](https://www.geeksforgeeks.org/permutation-and-combination-in-python/)

[Writing CSV files in Python](https://www.programiz.com/python-programming/writing-csv-files)

[Personalizing a Model with On-Device Updates](https://developer.apple.com/documentation/coreml/core_ml_api/personalizing_a_model_with_on-device_updates)

[Visual Language Format](https://www.raywenderlich.com/277-auto-layout-visual-format-language-tutorial)

[Connecting Swift to Core ML](https://www.hackingwithswift.com/books/ios-swiftui/connecting-swiftui-to-core-ml)